mpirun -n 4 python -m mpi4py.futures cnsga.py
